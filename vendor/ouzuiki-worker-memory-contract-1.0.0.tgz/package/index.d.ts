export type RecallStatus = "disabled" | "skipped_resumed" | "hit" | "miss" | "timeout" | "error";
export type WritebackStatus = "disabled" | "skipped" | "written" | "failed";
export interface ProjectScope { readonly projectRoot: string; readonly teamId: string }
export interface MemoryIdentity { readonly scope: ProjectScope; readonly teamId: string; readonly agentId: string; readonly userId: string; readonly sessionId: string }
export interface MemoryPolicy { readonly recallEnabled: boolean; readonly writebackEnabled: boolean; readonly agentId: string; readonly userId: string; readonly sessionId: string; readonly recallLimit: number; readonly recallTimeoutMs: number; readonly recallMaxChars: number; readonly writebackTimeoutMs: number; readonly writebackMaxChars: number }
export interface MemoryPort {
  atomicSearch(input: { teamId: string; agentId: string; userId: string; sessionId: string; query: string; limit: number }): Promise<{ items: unknown[] }>;
  conversationAdd(input: { teamId: string; agentId: string; userId: string; sessionId: string; messages: Array<{ role: "user" | "assistant"; content: string }> }): Promise<unknown>;
}
export interface RecallAcknowledgement { status: RecallStatus; team_id?: string; hit_count?: number; injected_chars?: number }
export function resolveProjectScope(cwd: string): ProjectScope;
export function readMemoryPolicy(env?: NodeJS.ProcessEnv): MemoryPolicy;
export function resolveMemoryIdentity(cwd: string, env?: NodeJS.ProcessEnv): MemoryIdentity;
export function sanitizeMemoryText(value: unknown): string;
export function recallForFreshRun(input: { originalTask: string; cwd: string; resumed?: boolean; client: MemoryPort; env?: NodeJS.ProcessEnv }): Promise<{ originalTask: string; effectiveTask: string; acknowledgement: RecallAcknowledgement }>;
export class CompletedWriteback {
  readonly originalTask: string;
  readonly identity: MemoryIdentity;
  readonly policy: MemoryPolicy;
  constructor(input: { originalTask: string; cwd: string; client: MemoryPort; env?: NodeJS.ProcessEnv });
  complete(finalResult: unknown): Promise<WritebackStatus>;
  skip(): Promise<WritebackStatus>;
}
